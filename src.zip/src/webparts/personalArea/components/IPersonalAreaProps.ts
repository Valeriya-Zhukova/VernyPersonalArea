export interface IPersonalAreaProps {
	description: string;
}
