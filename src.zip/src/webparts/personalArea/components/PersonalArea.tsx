import * as React from 'react';
import styles from './PersonalArea.module.scss';
import { IPersonalAreaProps } from './IPersonalAreaProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { IErrand, ILogin, IPersonalInfo, IVacation } from './interfaces';
import { Pivot, PivotItem } from 'office-ui-fabric-react/lib/Pivot';
import { SPFI, spfi } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/site-users/web';
import { Icon } from 'office-ui-fabric-react';
import { getSP } from '../pnpjsConfig';
import { ICamlQuery } from '@pnp/sp/lists';

export interface IAsyncAwaitPnPJsProps {
	description: string;
}

export interface IPersonalAreaState {
	personalInfo: IPersonalInfo;
	login: ILogin;
	vacation: IVacation;
	errand: IErrand;
}

export default class PersonalArea extends React.Component<IPersonalAreaProps, IPersonalAreaState> {
	private _sp: SPFI;

	constructor(props: IPersonalAreaProps, state: IPersonalAreaState) {
		super(props);
		// set initial state
		this.state = {
			personalInfo: {
				Title: 'User not found',
				post: '',
				division: '',
				Phone: '',
				Mobile: '',
				acceptd: '',
				vacation: '',
			},
			login: {
				userName: '',
				email: '',
			},
			vacation: {
				vacationDays: 14,
				to: '',
				from: '',
			},
			errand: {
				errandDays: 10,
				to: '',
				from: '',
			},
		};
		this._sp = getSP();
	}

	// после монтирования компонента обновить state
	public componentDidMount(): void {
		this._getUserPersonalInfo();
		this._getUserVacationsErrandsInfo();
		console.log(this.state);
	}

	public render(): React.ReactElement<IPersonalAreaProps> {
		return (
			<div className={styles.personalArea}>
				<div className={`${styles.container} ${styles.round}`}>
					<div className={`${styles.profileWrapper}`}>
						<header className={`${styles.topHeader}`}>
							<h3 className={`${styles.header}`}>Личный кабинет</h3>
						</header>
						<Pivot>
							<PivotItem headerText='Инфо'>
								<div className={`${styles.tabContent}`}>
									<div className={`${styles.fade} ${styles.active}`} id={'info'}>
										<div className={`${styles.tabContentWrapper}`}>
											<section className={`${styles.generalInfo} ${styles.round}`}>
												<div className={`${styles.card}`}>
													<div className={`${styles.cardHeader}`}>
														<div className={`${styles.name}`}>
															<span>{this.state.personalInfo.Title}</span>
														</div>
													</div>
													<div className={`${styles.cardBody}`}>
														<div className={`${styles.flexRow}`}>
															<div className={`${styles.image}`}>
																<img
																	className={`${styles.photo}`}
																	// src={`/_vti_bin/DelveApi.ashx/people/profileimage?size=L&amp;userId=${this.state.login.userName}`}
																	src={`/_layouts/15/userphoto.aspx?size=L&username=${this.state.login.email}`}
																/>
															</div>
														</div>
													</div>
												</div>
											</section>
											<section className={`${styles.details} ${styles.round}`}>
												<div className={`${styles.card}`}>
													<div className={`${styles.cardHeader}`}>
														<i className="${getIconclassName('Info')} ${styles.headerIcon}"></i>Личная информация
													</div>
													<div className={`${styles.cardBody}`}>
														<ul className={`${styles.detailsList}`}>
															<li id='job'>
																<div className={`${styles.detailsItem}`}>
																	<div className={`${styles.detailsItemTitle}`}>Должность</div>
																	<div className={`${styles.detailsItemValue}`}>{this.state.personalInfo.post}</div>
																</div>
															</li>
															<li id='department'>
																<div className={`${styles.detailsItem}`}>
																	<div className={`${styles.detailsItemTitle}`}>Департамент</div>
																	<div className={`${styles.detailsItemValue}`}>{this.state.personalInfo.division}</div>
																</div>
															</li>
															<li id='internalNumber'>
																<div className={`${styles.detailsItem}`}>
																	<div className={`${styles.detailsItemTitle}`}>Внутренний номер</div>
																	<div className={`${styles.detailsItemValue}`}>{this.state.personalInfo.Phone}</div>
																</div>
															</li>
															<li id='phoneNumber'>
																<div className={`${styles.detailsItem}`}>
																	<div className={`${styles.detailsItemTitle}`}>Номер телефона</div>
																	<div className={`${styles.detailsItemValue}`}>{this.state.personalInfo.Mobile}</div>
																</div>
															</li>
															<li id='email'>
																<div className={`${styles.detailsItem}`}>
																	<div className={`${styles.detailsItemTitle}`}>Email</div>
																	<div className={`${styles.detailsItem}value`}>{this.state.login.email}</div>
																</div>
															</li>
															<li id='worksFrom'>
																<div className={`${styles.detailsItem}`}>
																	<div className={`${styles.detailsItemTitle}`}>Работает в ТОО Verny Capital c</div>
																	<div className={`${styles.detailsItemValue}`}>{this.state.personalInfo.acceptd}</div>
																</div>
															</li>
															<li id='currentJobFrom'>
																<div className={`${styles.detailsItem}`}>
																	<div className={`${styles.detailsItemTitle}`}>Дней отпуска</div>
																	<div className={`${styles.detailsItemValue}`}>{this.state.personalInfo.vacation}</div>
																</div>
															</li>
														</ul>
													</div>
												</div>
											</section>
											<section className={`${styles.breakColumn}`}></section>
											<section className={`${styles.links}`}>
												<div className={`${styles.card} ${styles.cardBlue}`}>
													<div className={`${styles.cardHeader}`}>
														<i className="${getIconClassName('Link')} ${styles.headerIcon}"></i>
														Полезные ссылки
													</div>
													<div className={`${styles.cardBody}`}>
														<a
															href='https://vernycapital.sharepoint.com/howto/Shared%20Documents/Forms/AllItems.aspx?viewid=a8fac01f%2D5f1b%2D4789%2Db2e9%2Dd6daf52fbbed'
															target='_blank'
															className={`${styles.link}`}
														>
															<button type='button' className={`${styles.btn} ${styles.btnDark}`}>
																<Icon iconName='PageList' className={`${styles.btnIcon}`}></Icon>
																Должностная Инструкция
															</button>
														</a>
														<a
															href='https://vernycapital.sharepoint.com/howto/Shared%20Documents/Forms/AllItems.aspx?viewid=a8fac01f%2D5f1b%2D4789%2Db2e9%2Dd6daf52fbbed'
															target='_blank'
															className={`${styles.link}`}
														>
															<button type='button' className={`${styles.btn} ${styles.btnDark}`}>
																<Icon iconName='ChangeEntitlements' className={`${styles.btnIcon}`}></Icon>
																Центр Инструкций
															</button>
														</a>
													</div>
												</div>
											</section>

											<section className={`${styles.hr}`}>
												<div className={`${styles.card} ${styles.cardBlue}`}>
													<div className={`${styles.cardHeader}`}>
														<Icon iconName='Processing' className={`${styles.btnIcon}`}></Icon>
														Системное управление сервисами
													</div>
													<div className={`${styles.cardBody}`}>
														<a
															href='https://bpm.vernycapital.com/itsm/itsm_form?uid=11e9ce85-ad35-47e0-91e8-3750fb1f6296'
															target='_blank'
															className={`${styles.link}`}
														>
															<button type='button' className={`${styles.btn} ${styles.btnDark}`}>
																<Icon iconName='PaymentCard' className={`${styles.btnIcon}`}></Icon>
																<i className="${getIconClassName('PaymentCard')} ${styles.btnIcon}"></i>
																Заявка на оплату
															</button>
														</a>
														<a href='https://bpm.vernycapital.com' target='_blank' className={`${styles.link}`}>
															<button type='button' className={`${styles.btn} ${styles.btnDark}`}>
																<Icon iconName='DocumentReply' className={`${styles.btnIcon}`}></Icon>
																Согласование документов
															</button>
														</a>
													</div>
												</div>
											</section>

											<section className={`${styles.hr}`}>
												<div className={`${styles.card} ${styles.cardBlue}`}>
													<div className={`${styles.cardHeader}`}>
														<Icon iconName='People' className={`${styles.btnIcon}`}></Icon>
														HR
													</div>
													<div className={`${styles.cardBody}`}>
														<a href='https://bpm.vernycapital.com' target='_blank' className={`${styles.link}`}>
															<button type='button' className={`${styles.btn} ${styles.btnDark}`}>
																<Icon iconName='ClipboardList' className={`${styles.btnIcon}`}></Icon>
																PAS
															</button>
														</a>
													</div>
												</div>
											</section>
										</div>
									</div>
								</div>
							</PivotItem>
							<PivotItem headerText='Отпуска'>
								<div className={`${styles.tabContentWrapper}`}>
									<section className={`${styles.generalInfo} ${styles.round}`}>
										<div className={`${styles.card}`}>
											<div className={`${styles.cardHeader}`}>
												<div className={`${styles.name}`}>
													<span>Дней отпуска с начала года: {this.state.vacation.vacationDays}</span>
												</div>
											</div>
											<div className={`${styles.cardBody}`}>
												<a
													href='https://vernycapital.sharepoint.com/Lists/OutOf/AllItems.aspx'
													target='_blank'
													className={`${styles.link}`}
												>
													<button type='button' className={`${styles.btn} ${styles.btnLightGreen}`}>
														<Icon iconName='Vacation' className={`${styles.btnIcon}`}></Icon>
														Посмотреть список
													</button>
												</a>
											</div>
										</div>
									</section>
								</div>
							</PivotItem>
							<PivotItem headerText='Командировки'>
								<div className={`${styles.tabContentWrapper}`}>
									<section className={`${styles.generalInfo} ${styles.round}`}>
										<div className={`${styles.card}`}>
											<div className={`${styles.cardHeader}`}>
												<div className={`${styles.name}`}>
													<span>Дней командировок с начала года: {this.state.errand.errandDays}</span>
												</div>
											</div>
											<div className={`${styles.cardBody}`}>
												<a
													href='https://vernycapital.sharepoint.com/Lists/OutOf/AllItems.aspx'
													target='_blank'
													className={`${styles.link}`}
												>
													<button type='button' className={`${styles.btn} ${styles.btnLightBlue}`}>
														<Icon iconName='Arrivals' className={`${styles.btnIcon}`}></Icon>
														Посмотреть список
													</button>
												</a>
											</div>
										</div>
									</section>
								</div>
							</PivotItem>
						</Pivot>
					</div>
				</div>
			</div>
		);
	}

	private _getUserPersonalInfo = async (): Promise<void> => {
		try {
			const sp = spfi(this._sp);

			const _email = (await sp.web.currentUser()).Email;
			const _userName = (await sp.web.currentUser()).UserPrincipalName;

			const item: object = await sp.web.lists
				.getByTitle('profile')
				.items.select('Title', 'post', 'Phone', 'Mobile', 'division', 'acceptd', 'vacation')
				.filter(`login eq \'${_userName}\'`)();

			console.log(item);

			const _login = { userName: _userName, email: _email };
			console.log(_login);

			const _personalInfo = {
				Title: item[0]?.Title,
				post: item[0]?.post,
				Phone: item[0]?.Phone,
				Mobile: item[0]?.Mobile,
				division: item[0]?.division,
				acceptd: item[0]?.acceptd,
				vacation: item[0]?.vacation,
			};

			// console.log(item[0].Title);

			this.setState({ personalInfo: _personalInfo, login: _login });
			console.log(this.state);
		} catch (err) {
			console.log(err);
		}
	};

	private _getUserVacationsErrandsInfo = async (): Promise<void> => {
		try {
			const sp = spfi(this._sp);

			const caml: ICamlQuery = {
				ViewXml: "<View><ViewFields><FieldRef Name='Title' /></ViewFields><RowLimit>5</RowLimit></View>",
			};

			// get list items

			const item: object = await sp.web.lists.getByTitle('Нет в офисе').items.select('Title', 'From', 'To', 'login')();
			const itemCaml: object = await sp.web.lists.getByTitle('Нет в офисе').getItemsByCAMLQuery(caml);

			const _vacation = {
				vacationDays: 14,
				from: item[1].From,
				to: item[1].To,
			};

			// console.log(_vacation);

			// const diffInTime = Date.parse(_vacation.to) - Date.parse(_vacation.from);
			// console.log(diffInTime);

			// const diffInDays = diffInTime / (1000 * 3600 * 24);
			// console.log(diffInDays);

			// const _vacationDays = diffInDays;
			// _vacation.vacationDays = _vacationDays;

			this.setState({ vacation: _vacation });
		} catch (error) {
			console.log(error);
		}
	};
}
