export interface IPersonalInfo {
	Title: string | string | '';
	post: string | '';
	division: string | '';
	Phone: string | '';
	Mobile: string | '';
	acceptd: string | '';
	vacation: string | '';
}

export interface ILogin {
	userName: string | '';
	email: string | '';
}

export interface IVacation {
	vacationDays: number | null;
	from: string | '';
	to: string | '';
}

export interface IErrand {
	errandDays: number | null;
	from: string | '';
	to: string | '';
}
