declare interface IPersonalAreaWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PersonalAreaWebPartStrings' {
  const strings: IPersonalAreaWebPartStrings;
  export = strings;
}
